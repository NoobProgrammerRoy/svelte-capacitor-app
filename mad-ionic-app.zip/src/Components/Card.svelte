<!-- Card component for pokemons, items and moves -->
<div class="w-11/12 border-0 shadow-md p-1 mx-auto">
    <slot>
        Card Component
    </slot>
</div>