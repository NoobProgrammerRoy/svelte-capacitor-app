<!-- Header component -->
<nav class="bg-gradient-to-r from-blue-600 to-blue-500 p-2">
    <header>
        <h1 class="text-xl text-gray-50 font-bold">PokePedia</h1>
    </header>
</nav>