<!-- Footer component -->
<footer class="absolute bottom-0 left-0 w-full p-2 bg-blue-700">
    <div class="flex flex-row justify-between items-center list-none">
        <a href="#/" class="flex flex-col items-center">
            <i class="fas fa-meteor text-gray-50" />
            <span class="text-sm text-gray-50">Pokemon</span>
        </a>
        <a href="#/items" class="flex flex-col items-center">
            <i class="fas fa-shield-alt text-gray-50" />
            <span class="text-sm text-gray-50">Items</span>
        </a>
        <a href="#/moves" class="flex flex-col items-center">
            <i class="fas fa-scroll text-gray-50" />
            <span class="text-sm text-gray-50">Moves</span>
        </a>
        <a href="#/about" class="flex flex-col items-center">
            <i class="fas fa-info-circle text-gray-50" />
            <span class="text-sm text-gray-50">About</span>
        </a>
    </div>
</footer>