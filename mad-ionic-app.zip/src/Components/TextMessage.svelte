<script>
    export let color;
    export let message;
</script>

<!-- Text message component -->
<p class="text-center text-sm {color}">
    {message}
</p>