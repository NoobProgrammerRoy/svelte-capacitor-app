<script>
    export let title;
</script>

<!-- Title component for each page -->
<h2 class="text-gray-900 text-center text-md font-bold my-2">
    {title}
</h2>