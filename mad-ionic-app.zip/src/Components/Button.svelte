<script>
    export let name;
</script>

<!-- Button component for forms -->
<button class="w-11/12 bg-blue-600 hover:bg-blue-700 text-gray-50 font-thin outline-none rounded-md my-2 py-1">
    {name}
</button>