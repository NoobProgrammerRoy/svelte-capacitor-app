<script>
    import Title from '../Components/Title.svelte';
</script>

<!-- About page -->
<div>
    <Title title={'About PokePedia'} />
    <p class="text-center text-sm text-gray-700 px-1">
        PokePedia is a one stop destination for all pokemon related information. 
        Search through hundreds and hundreds of pokemons, items and moves. 
        Your very own pokedex, at the palm of your hands.
    </p>
    <p class="text-center text-xl text-yellow-500 font-bold my-2">
        Gotta Catch 'em All !
    </p>
</div>